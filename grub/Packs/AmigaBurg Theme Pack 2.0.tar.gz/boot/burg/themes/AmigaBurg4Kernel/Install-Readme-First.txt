I claim no ownership of anything herein. This is a modification on burg theme "Fortune"

Deposit in directory /boot/burg/themes/
Change to theme at boot time using burg.

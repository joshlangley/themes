I claim no ownership of anything herein. These are modifications of burg theme "Fortune"
Contained are Amiga Boot themes for version: 1.3, 2.0, 3.1, 3.1.4, 3.9, 3.9 SD Card, 4 Kernel, and a nice black 4.1 final.

Copy the boot directory contained here to /
example: sudo cp -r boot /

Update burg
example: sudo update-burg

Then change to your desired theme upon boot, or using :
sudo burg-emu

